/*
 * Done with the team:
 * Praneeth Palakruthi
 * Kunal Krishna
 * */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.json.JSONObject;

//adhering the structure of location
public class FacilityDecision {

	Map<String, String> Location_Closeby;
	Map<String, String> MyMap;
	Map<String, YardLocation> MapAddition;

	FacilityDecision() {
		Location_Closeby = new HashMap<String, String>();
	}

// The Location Class contains StateCode, State Name, Phone Number, Zipcode.
public class YardLocation {
		String S_Code;
		String state;
		String phoneNumber;
		String zipCode;
		
		public static void main(String args[]) throws Exception {
			String customerID;
			String zipCode;
			Scanner s = new Scanner(System.in);
			FacilityDecision nCopart = new FacilityDecision();
			nCopart.MapAddition = nCopart.getLocationInput(new File("Locations.csv"));
			nCopart.MyMap = nCopart.getCustomerInput(new File("CustomerLocation.csv"));
			System.out.println("Enter Customer ID and Zip code");
			while (s.hasNext()) {
				customerID = s.nextLine();
				zipCode = s.nextLine();
				if (customerID.length() > 1 && zipCode.length() > 1)
					System.out.println(nCopart.getNearestLocation(customerID, zipCode));
				System.out.println("Enter CustomerID, Zip code");
			}
			s.close();
		}

		public YardLocation(String S_Code, String state, String phoneNumber, String zipCode) {
			this.S_Code = S_Code;
			this.state = state;
			this.phoneNumber = phoneNumber;
			this.zipCode = zipCode;
		}

		public String toString() {
			return this.S_Code + " " + this.state + " " + this.phoneNumber;
		}
	}



// In this function data is being  added into a Hashmap with the Zipcode as the key/
	public Map<String, YardLocation> getLocationInput(File file) throws FileNotFoundException {
		Scanner s = new Scanner(file);
		HashMap<String, YardLocation> hm = new HashMap<>();
		while (s.hasNextLine()) {
			try {
				String now = s.nextLine();
				String str[] = now.split(",");
				YardLocation copartLoc = new YardLocation(str[0], str[1], str[str.length - 2], str[str.length - 4]);
				hm.put(str[str.length - 4], copartLoc);
			} catch (Exception e) {
				// just skip mismatched locations
			}
		}
		s.close();
		return hm;
	}

//parsing customerLocations.csv file
//data is being added into a Hashmap with the Zipcode as the key.

	public Map<String, String> getCustomerInput(File file) throws Exception {
		Scanner s = new Scanner(file);
		HashMap<String, String> hm = new HashMap<>();
		while (s.hasNextLine()) {
			try {
				String now = s.nextLine();
				String str[] = now.split(",");
				hm.put(str[0], str[1]);
			} catch (Exception e) {
			}
		}

		s.close();
		return hm;
	}

// in this function we check the given zip code with all the other zip codes and produce the zipcode according to the minimum distance
	public YardLocation getNearestLocation(String customerID, String zipCode) {
		if (MyMap.containsKey(customerID))
			return MapAddition.get(MyMap.get(customerID));
		if (Location_Closeby.containsKey(zipCode)) {
			return MapAddition.get(Location_Closeby.get(zipCode));
		}

		double distanceMin = Double.MAX_VALUE;
		String minZipCode = null;
		System.out.println("Fetching from API............");
		for (Object zip : MapAddition.keySet()) {
			double value = getDistance(zipCode, (String) zip);
			if (value < distanceMin) {
				distanceMin = value;
				minZipCode = (String) zip;
			}
		}
		Location_Closeby.put(zipCode, minZipCode);
		return MapAddition.get(minZipCode);
	}

// In this function we get distance between two zipcode using zipcode api
	
	public double getDistance(String zip1, String zip2) {
		String API_Key = "wuBC8LO1XFIu4BX8FLXGYvTvF6XVr7cYBNAKzpLw4t195YhLKesIKldqsbmUiySU";
		String url = "https://www.zipcodeapi.com/rest/" + API_Key + "/distance.json/" + zip1 + "/" + zip2 + "/km";
		String inputLine;
		try {
			URL ur = new URL(url);
			HttpURLConnection con = (HttpURLConnection) ur.openConnection();
			con.setRequestMethod("GET");
			BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
			inputLine = reader.readLine();
			JSONObject json = new JSONObject(inputLine);
			String distance = json.getString("distance");
			return Double.parseDouble(distance);
		} catch (Exception e) {
			return Integer.MAX_VALUE;
		}
	}

}