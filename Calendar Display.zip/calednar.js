$(document).ready(function(){
        $('table td').click(function(){
            window.location = $(this).data('href');
            return false;
        });
    });